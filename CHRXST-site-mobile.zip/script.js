let cart = [];

function addToCart(name, price) {
  const existing = cart.find(item => item.name === name);
  if (existing) {
    existing.qty += 1;
  } else {
    cart.push({ name, price, qty: 1 });
  }
  renderCart();
}

function renderCart() {
  const cartContainer = document.getElementById("cart-items");
  const totalContainer = document.getElementById("cart-total");
  cartContainer.innerHTML = "";
  let total = 0;
  cart.forEach(item => {
    const line = document.createElement("div");
    line.innerHTML = `${item.name} x${item.qty} – ${item.price * item.qty}€`;
    cartContainer.appendChild(line);
    total += item.price * item.qty;
  });
  totalContainer.innerText = `Total : ${total}€`;
  document.getElementById("cart").style.display = "block";
}